from project.album import Album


class Band:
    def __init__(self, name):
        self.name = name
        self.albums = []

    def add_album(self, new_album: Album):
        for album in self.albums:
            if album.name == new_album:
                return f"Band {self.name} already has {new_album} in their library."

        self.albums.append(new_album)
        return f"Band {self.name} has added their newest album {new_album.name}."

    def remove_album(self, album_name: str):

        for album in self.albums:
            if album.name == album_name:
                if album.published:
                    return "Album has been published. It cannot be removed."
                else:
                    self.albums.remove(album_name)
                    return f"Album {album_name} has been removed."

        return f"Album {album_name} is not found."

    def details(self):
        data = f"Band {self.name}\n"
        for album in self.albums:
            data += album.details()
        return data
